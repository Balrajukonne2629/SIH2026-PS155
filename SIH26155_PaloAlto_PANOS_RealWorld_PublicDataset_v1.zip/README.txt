REAL-WORLD PUBLIC SOURCE DATASET
================================
This package contains configuration/source material taken from public repositories identified in the research for SIH26155.

It is NOT a synthetic configuration dataset. It is also NOT claimed to be a production customer configuration corpus. Compliance labels are intentionally not fabricated. Verify each source against the exact benchmark/version before assigning PASS/FAIL/UNKNOWN.

Sensitive credentials or secrets visible in public examples have not been included where they were not necessary for the research dataset.
